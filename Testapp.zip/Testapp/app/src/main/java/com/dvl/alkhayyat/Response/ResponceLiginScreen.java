package com.dvl.alkhayyat.Response;

import java.util.List;

import com.dvl.alkhayyat.Interface.Datum;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ResponceLiginScreen {

@SerializedName("statuscode")
@Expose
private Integer statuscode;
@SerializedName("message")
@Expose
private String message;
@SerializedName("data")
@Expose
private List<Datum> data = null;
@SerializedName("imagepath")
@Expose
private String imagepath;
@SerializedName("token")
@Expose
private String token;

public Integer getStatuscode() {
return statuscode;
}

public void setStatuscode(Integer statuscode) {
this.statuscode = statuscode;
}

public String getMessage() {
return message;
}

public void setMessage(String message) {
this.message = message;
}

public List<Datum> getData() {
return data;
}

public void setData(List<Datum> data) {
this.data = data;
}

public String getImagepath() {
return imagepath;
}

public void setImagepath(String imagepath) {
this.imagepath = imagepath;
}

public String getToken() {
return token;
}

public void setToken(String token) {
this.token = token;
}

}