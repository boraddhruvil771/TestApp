package com.dvl.alkhayyat.Response;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    @SerializedName("username")
    public String username;
    @SerializedName("password")
    public String password;
    @SerializedName("userType")
    public String userType;
    @SerializedName("customer_id")
    public String customer_id;
    @SerializedName("email")
    public String email;
    @SerializedName("contact_no")
    public String contact_no;
    @SerializedName("firstname")
    public String firstname;
    @SerializedName("lastname")
    public String lastname;
    @SerializedName("imagepath")
    public String imagepath;
    @SerializedName("loyalti_profildid")
    public String loyalti_profildid;
    @SerializedName("total_points_earned")
    public int total_points_earned;
    @SerializedName("total_points_redmeemed")
    public int total_points_redmeemed;
    @SerializedName("total_points_avilable")
    public int total_points_avilable;
    @SerializedName("total_points_expiring")
    public int total_points_expiring;
    @SerializedName("dob")
    public String dob;
    @SerializedName("token")
    public String token;

    @SerializedName("statuscode")
    public String statuscode;
    @SerializedName("message")
    public String message;

    public LoginResponse(String username, String password,String userType) {
        this.username = username;
        this.password = password;
        this.userType = userType;}


    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getStatuscode() {
        return statuscode;
    }

    public void setStatuscode(String statuscode) {
        this.statuscode = statuscode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getImagepath() {
        return imagepath;
    }

    public void setImagepath(String imagepath) {
        this.imagepath = imagepath;
    }

    public String getLoyalti_profildid() {
        return loyalti_profildid;
    }

    public void setLoyalti_profildid(String loyalti_profildid) {
        this.loyalti_profildid = loyalti_profildid;
    }

    public int getTotal_points_earned() {
        return total_points_earned;
    }

    public void setTotal_points_earned(int total_points_earned) {
        this.total_points_earned = total_points_earned;
    }

    public int getTotal_points_redmeemed() {
        return total_points_redmeemed;
    }

    public void setTotal_points_redmeemed(int total_points_redmeemed) {
        this.total_points_redmeemed = total_points_redmeemed;
    }

    public int getTotal_points_avilable() {
        return total_points_avilable;
    }

    public void setTotal_points_avilable(int total_points_avilable) {
        this.total_points_avilable = total_points_avilable;
    }

    public int getTotal_points_expiring() {
        return total_points_expiring;
    }

    public void setTotal_points_expiring(int total_points_expiring) {
        this.total_points_expiring = total_points_expiring;
    }

    public String getRespondobseMessage() {
        return dob;
    }

    public void setRespondobseMessage(String respondobseMessage) {
        dob = respondobseMessage;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}
