package com.dvl.alkhayyat.Interface;

import com.dvl.alkhayyat.Response.LoginResponse;
import com.dvl.alkhayyat.Response.ResponceLiginScreen;
import com.dvl.alkhayyat.Response.ResponceProdScreen;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface APIInterface {

    @POST("login/authenticate")
    Call<LoginResponse> createUser(@Body LoginResponse login);

    @POST("login/authenticate")
    @FormUrlEncoded
    Call<ResponceLiginScreen> sendLogin(@Field("username") String username,
                                        @Field("password") String password,
                                        @Field("userType") String userType);


    @POST("commonAPI/productMst_list")
    @FormUrlEncoded
    Call<ResponceProdScreen> sendProduct(@Field("Product_iD") String Product_iD,
                                         @Field("PageNo") String password,
                                         @Field("PageSize") String userType,
                                         @Field("Search") String search);

}
