package com.dvl.alkhayyat.Interface;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Productdata {

    @SerializedName("product_iD")
    @Expose
    private Integer productID;
    @SerializedName("product_name")
    @Expose
    private String productName;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("category")
    @Expose
    private String category;
    @SerializedName("sub_Category")
    @Expose
    private String subCategory;
    @SerializedName("uom")
    @Expose
    private String uom;
    @SerializedName("price")
    @Expose
    private Double price;
    @SerializedName("weight")
    @Expose
    private String weight;
    @SerializedName("size")
    @Expose
    private String size;
    @SerializedName("product_rank")
    @Expose
    private Integer productRank;
    @SerializedName("product_image")
    @Expose
    private String productImage;
    @SerializedName("brand")
    @Expose
    private String brand;
    @SerializedName("product_code")
    @Expose
    private String productCode;
    @SerializedName("disclose_price")
    @Expose
    private Boolean disclosePrice;
    @SerializedName("alter_price_text")
    @Expose
    private String alterPriceText;
    @SerializedName("points_to_earn")
    @Expose
    private Double pointsToEarn;

    public Integer getProductID() {
        return productID;
    }

    public void setProductID(Integer productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Integer getProductRank() {
        return productRank;
    }

    public void setProductRank(Integer productRank) {
        this.productRank = productRank;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Boolean getDisclosePrice() {
        return disclosePrice;
    }

    public void setDisclosePrice(Boolean disclosePrice) {
        this.disclosePrice = disclosePrice;
    }

    public String getAlterPriceText() {
        return alterPriceText;
    }

    public void setAlterPriceText(String alterPriceText) {
        this.alterPriceText = alterPriceText;
    }

    public Double getPointsToEarn() {
        return pointsToEarn;
    }

    public void setPointsToEarn(Double pointsToEarn) {
        this.pointsToEarn = pointsToEarn;
    }
}
