package com.dvl.alkhayyat.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.dvl.alkhayyat.R;
import com.dvl.alkhayyat.Response.LoginResponse;

import de.hdodenhof.circleimageview.CircleImageView;

public class GalleryFragment extends Fragment {

    private GalleryViewModel galleryViewModel;
    TextView firstname, lastname, emailid, phone;
    LoginResponse loginResponse;
    CircleImageView circleImageView;

    String fname, Lname, ename, Pname, imagestring;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View view = inflater.inflate(R.layout.fragment_gallery, container, false);

        firstname = view.findViewById(R.id.firstname);
        lastname = view.findViewById(R.id.firstname);
        emailid = view.findViewById(R.id.firstname);
        phone = view.findViewById(R.id.firstname);
        circleImageView = view.findViewById(R.id.profile_image_round);

//        fname = loginResponse.getFirstname().toString();
//        Lname = loginResponse.getLastname().toString();
//        ename = loginResponse.getEmail().toString();
//        Pname = loginResponse.getContact_no().toString();
//        imagestring = loginResponse.getImagepath();

//        firstname.setText(fname);
//        lastname.setText(Lname);
//        emailid.setText(ename);
//        phone.setText(Pname);

        return view;
    }
}