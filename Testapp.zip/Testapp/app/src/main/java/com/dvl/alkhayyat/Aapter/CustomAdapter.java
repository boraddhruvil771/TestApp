package com.dvl.alkhayyat.Aapter;

import androidx.recyclerview.widget.RecyclerView;

public class CustomAdapter {
}
