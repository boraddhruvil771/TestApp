package com.dvl.alkhayyat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.dvl.alkhayyat.Api.APIClient;
import com.dvl.alkhayyat.Interface.APIInterface;
import com.dvl.alkhayyat.Response.LoginResponse;
import com.dvl.alkhayyat.Response.ResponceLiginScreen;
import com.dvl.alkhayyat.Splash.CommonMethod;
import com.google.gson.Gson;

import java.util.zip.Inflater;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    APIInterface apiInterface;
    Button loginSub;
    EditText et_Email, et_Pass;

    String userId, password;
    String totalpoint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apiInterface = (APIInterface) APIClient.getClient().create(APIInterface.class);

        loginSub = (Button) findViewById(R.id.loginSub);
        et_Email = (EditText) findViewById(R.id.edtEmail);
        et_Pass = (EditText) findViewById(R.id.edtPass);


        loginSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkValidation()) {
                    if (CommonMethod.isNetworkAvailable(MainActivity.this))
                        loginRetrofit2Api(userId, password);
                        //sendLogin(userId,password);

                    else
                        CommonMethod.showAlert("Internet Connectivity Failure", MainActivity.this);
                }
            }

            private void loginRetrofit2Api(final String username, String password) {
                final LoginResponse login = new LoginResponse(username, password, "C");

                Call<LoginResponse> call1 = apiInterface.createUser(login);

                call1.enqueue(new Callback<LoginResponse>() {
                    @Override
                    public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                        Log.e("reasponse...", new Gson().toJson(response.body()));
                        LoginResponse loginResponse = response.body();

                        Log.e("dhruvil", "loginResponse 1 --> " + loginResponse);
                        if (loginResponse != null) {

                            Log.e("dhruvil", "getUserId          -->  " + loginResponse.getCustomer_id());
                            Log.e("dhruvil", "getFirstName       -->  " + loginResponse.getFirstname());
                            Log.e("dhruvil", "getLastName        -->  " + loginResponse.getLastname());
                            Log.e("dhruvil", "getProfilePicture  -->  " + loginResponse.getImagepath());

                            String responseCode = loginResponse.getStatuscode();
                            Log.d("responsecode", responseCode + "");

                            if (responseCode != null && responseCode.equals("404")) {
                                Toast.makeText(MainActivity.this, "Invalid Login Details \n Please try again", Toast.LENGTH_SHORT).show();
                            } else {

                                Toast.makeText(MainActivity.this, "Hello Welcome " + userId, Toast.LENGTH_SHORT).show();

                                String tokenmain = loginResponse.getToken();
//                                String firstname =loginResponse.getFirstname();
                                Toast.makeText(MainActivity.this, "laile" + tokenmain, Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), Mainscreen.class);
                                intent.putExtra("token", tokenmain);
                                startActivity(intent);

                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponse> call, Throwable t) {
                        t.printStackTrace();
                        Toast.makeText(MainActivity.this, "Enter valid Details", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            private boolean checkValidation() {
                userId = et_Email.getText().toString();
                password = et_Pass.getText().toString();

                Log.e("dhruvil", "userId is -> " + userId);
                Log.e("dhruvil", "password is -> " + password);

                if (et_Email.getText().toString().trim().equals("")) {
                    CommonMethod.showAlert("UserId Cannot be left blank", MainActivity.this);
                    return false;
                } else if (et_Pass.getText().toString().trim().equals("")) {
                    CommonMethod.showAlert("password Cannot be left blank", MainActivity.this);
                    return false;
                }
                return true;
            }

        });
    }

    public void sendLogin(String username, String password) {

        APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);

        Call<ResponceLiginScreen> call = apiInterface.sendLogin(username, password, "C");

        call.enqueue(new Callback<ResponceLiginScreen>() {
            @Override
            public void onResponse(Call<ResponceLiginScreen> call, Response<ResponceLiginScreen> response) {

                Log.e("Loginresponse...", new Gson().toJson(response.body()));
//                Toast.makeText(MainActivity.this, "Hello Welcome " + loginSub.getFirstname(), Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), Mainscreen.class);
                startActivity(intent);

            }

            @Override
            public void onFailure(Call<ResponceLiginScreen> call, Throwable t) {
                t.printStackTrace();
                Log.e("error", t.getMessage());

            }
        });


    }
}