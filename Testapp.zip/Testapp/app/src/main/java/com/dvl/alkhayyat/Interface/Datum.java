package com.dvl.alkhayyat.Interface;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {

@SerializedName("customer_id")
@Expose
private Integer customerId;
@SerializedName("email")
@Expose
private String email;
@SerializedName("contact_no")
@Expose
private String contactNo;
@SerializedName("first_name")
@Expose
private String firstName;
@SerializedName("last_name")
@Expose
private String lastName;
@SerializedName("image_path")
@Expose
private String imagePath;
@SerializedName("loyalty_profileid")
@Expose
private String loyaltyProfileid;
@SerializedName("total_points_earned")
@Expose
private Double totalPointsEarned;
@SerializedName("total_points_redeemed")
@Expose
private Double totalPointsRedeemed;
@SerializedName("total_points_available")
@Expose
private Double totalPointsAvailable;
@SerializedName("total_points_expiring")
@Expose
private Double totalPointsExpiring;
@SerializedName("dob")
@Expose
private String dob;

public Integer getCustomerId() {
return customerId;
}

public void setCustomerId(Integer customerId) {
this.customerId = customerId;
}

public String getEmail() {
return email;
}

public void setEmail(String email) {
this.email = email;
}

public String getContactNo() {
return contactNo;
}

public void setContactNo(String contactNo) {
this.contactNo = contactNo;
}

public String getFirstName() {
return firstName;
}

public void setFirstName(String firstName) {
this.firstName = firstName;
}

public String getLastName() {
return lastName;
}

public void setLastName(String lastName) {
this.lastName = lastName;
}

public String getImagePath() {
return imagePath;
}

public void setImagePath(String imagePath) {
this.imagePath = imagePath;
}

public String getLoyaltyProfileid() {
return loyaltyProfileid;
}

public void setLoyaltyProfileid(String loyaltyProfileid) {
this.loyaltyProfileid = loyaltyProfileid;
}

public Double getTotalPointsEarned() {
return totalPointsEarned;
}

public void setTotalPointsEarned(Double totalPointsEarned) {
this.totalPointsEarned = totalPointsEarned;
}

public Double getTotalPointsRedeemed() {
return totalPointsRedeemed;
}

public void setTotalPointsRedeemed(Double totalPointsRedeemed) {
this.totalPointsRedeemed = totalPointsRedeemed;
}

public Double getTotalPointsAvailable() {
return totalPointsAvailable;
}

public void setTotalPointsAvailable(Double totalPointsAvailable) {
this.totalPointsAvailable = totalPointsAvailable;
}

public Double getTotalPointsExpiring() {
return totalPointsExpiring;
}

public void setTotalPointsExpiring(Double totalPointsExpiring) {
this.totalPointsExpiring = totalPointsExpiring;
}

public String getDob() {
return dob;
}

public void setDob(String dob) {
this.dob = dob;
}

}