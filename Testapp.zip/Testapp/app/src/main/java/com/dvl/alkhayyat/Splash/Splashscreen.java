package com.dvl.alkhayyat.Splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.dvl.alkhayyat.MainActivity;
import com.dvl.alkhayyat.Mainscreen;
import com.dvl.alkhayyat.R;
import com.dvl.alkhayyat.Response.LoginResponse;

public class Splashscreen extends AppCompatActivity {

    LoginResponse loginResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


//                if (loginResponse.getUsername() != "") {
//                    Intent intent = new Intent(Splashscreen.this, Mainscreen.class);
//                    startActivity(intent);
//                    finish();
//                } else {
                    Intent intent = new Intent(Splashscreen.this, MainActivity.class);
                    startActivity(intent);
                    finish();
//                }


//                Intent mainIntent = new Intent(Splashscreen.this, MainActivity.class);
//                Splashscreen.this.startActivity(mainIntent);
//                Splashscreen.this.finish();
            }
        }, 3000);
    }

}
