package com.dvl.alkhayyat.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dvl.alkhayyat.Api.APIClient;
import com.dvl.alkhayyat.Interface.APIInterface;
import com.dvl.alkhayyat.R;
import com.dvl.alkhayyat.Response.Dataresponse;
import com.dvl.alkhayyat.Response.LoginResponse;
import com.dvl.alkhayyat.Response.ResponceLiginScreen;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    APIInterface apiInterface;
    Dataresponse loginResponse;
    RecyclerView recyclerView;

    TextView textfirstnmae, emailidtext, totalpoint, earnedpoint, expiringpoint, remeedpoint;
    String firstname, email, toalp, currento, expiringp, redmeedp;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        textfirstnmae = view.findViewById(R.id.firstname);
        emailidtext = view.findViewById(R.id.emailidtext);
        totalpoint = view.findViewById(R.id.totalpoint);
        earnedpoint = view.findViewById(R.id.earnedpoint);
        expiringpoint = view.findViewById(R.id.expiringpoint);
        remeedpoint = view.findViewById(R.id.remeedpoint);
        recyclerView = view.findViewById(R.id.recyclerviewmain);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        //        apiInterface = (APIInterface) APIClient.getClient().create(APIInterface.class);


        return view;
    }
}