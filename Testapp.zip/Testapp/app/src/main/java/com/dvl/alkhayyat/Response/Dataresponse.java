package com.dvl.alkhayyat.Response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Dataresponse {

    @SerializedName("customer_id")
    @Expose
    private Integer customerId;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("contact_no")
    @Expose
    private String contactNo;
    @SerializedName("first_name")
    @Expose
    private String firstName;
    @SerializedName("last_name")
    @Expose
    private String lastName;
    @SerializedName("image_path")
    @Expose
    private String imagePath;
    @SerializedName("loyalty_profileID")
    @Expose
    private String loyaltyProfileID;
    @SerializedName("total_points_earned")
    @Expose
    private Integer totalPointsEarned;
    @SerializedName("total_points_redeemed")
    @Expose
    private Integer totalPointsRedeemed;
    @SerializedName("total_points_available")
    @Expose
    private Integer totalPointsAvailable;
    @SerializedName("total_points_expiring")
    @Expose
    private Integer totalPointsExpiring;
    @SerializedName("dob")
    @Expose
    private String dob;

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getLoyaltyProfileID() {
        return loyaltyProfileID;
    }

    public void setLoyaltyProfileID(String loyaltyProfileID) {
        this.loyaltyProfileID = loyaltyProfileID;
    }

    public Integer getTotalPointsEarned() {
        return totalPointsEarned;
    }

    public void setTotalPointsEarned(Integer totalPointsEarned) {
        this.totalPointsEarned = totalPointsEarned;
    }

    public Integer getTotalPointsRedeemed() {
        return totalPointsRedeemed;
    }

    public void setTotalPointsRedeemed(Integer totalPointsRedeemed) {
        this.totalPointsRedeemed = totalPointsRedeemed;
    }

    public Integer getTotalPointsAvailable() {
        return totalPointsAvailable;
    }

    public void setTotalPointsAvailable(Integer totalPointsAvailable) {
        this.totalPointsAvailable = totalPointsAvailable;
    }

    public Integer getTotalPointsExpiring() {
        return totalPointsExpiring;
    }

    public void setTotalPointsExpiring(Integer totalPointsExpiring) {
        this.totalPointsExpiring = totalPointsExpiring;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }
}
